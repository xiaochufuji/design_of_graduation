/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.13.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSlider>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *gridLayout_3;
    QVBoxLayout *verticalLayout_2;
    QSpacerItem *verticalSpacer_2;
    QGridLayout *gridLayout;
    QComboBox *m_drugBox;
    QLabel *m_currentSpeedLabel;
    QLabel *m_currentDrugLabel;
    QLabel *m_suggestSpeedLabel;
    QHBoxLayout *horizontalLayout;
    QLabel *m_minSuggestSpeed;
    QLabel *m_toPattern;
    QLabel *m_maxSuggestSpeed;
    QHBoxLayout *horizontalLayout_2;
    QLabel *m_currentSpeedText;
    QLabel *m_currentSpeed__;
    QSpacerItem *verticalSpacer;
    QSpacerItem *verticalSpacer_4;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout_4;
    QSpacerItem *horizontalSpacer;
    QSlider *m_slider;
    QSpacerItem *horizontalSpacer_2;
    QLabel *m_sliderTimes;
    QVBoxLayout *verticalLayout_5;
    QLabel *m_blueteethLabel;
    QHBoxLayout *horizontalLayout_5;
    QListWidget *listWidget;
    QVBoxLayout *verticalLayout_4;
    QPushButton *m_openBluetoothButton;
    QPushButton *m_freshButton;
    QPushButton *m_connectButton;
    QPushButton *m_breakButton;
    QGridLayout *gridLayout_2;
    QHBoxLayout *horizontalLayout_3;
    QLabel *m_restNumLabel;
    QLabel *m_restNum;
    QSpacerItem *verticalSpacer_3;
    QMenuBar *menubar;
    QMenu *menu;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(569, 938);
        QSizePolicy sizePolicy(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(centralwidget->sizePolicy().hasHeightForWidth());
        centralwidget->setSizePolicy(sizePolicy1);
        gridLayout_3 = new QGridLayout(centralwidget);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        verticalLayout_2 = new QVBoxLayout();
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalSpacer_2 = new QSpacerItem(20, 100, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_2->addItem(verticalSpacer_2);

        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        m_drugBox = new QComboBox(centralwidget);
        m_drugBox->addItem(QString());
        m_drugBox->addItem(QString());
        m_drugBox->addItem(QString());
        m_drugBox->setObjectName(QString::fromUtf8("m_drugBox"));
        QFont font;
        font.setPointSize(24);
        m_drugBox->setFont(font);

        gridLayout->addWidget(m_drugBox, 0, 1, 1, 1);

        m_currentSpeedLabel = new QLabel(centralwidget);
        m_currentSpeedLabel->setObjectName(QString::fromUtf8("m_currentSpeedLabel"));
        m_currentSpeedLabel->setFont(font);
        m_currentSpeedLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(m_currentSpeedLabel, 2, 0, 1, 1);

        m_currentDrugLabel = new QLabel(centralwidget);
        m_currentDrugLabel->setObjectName(QString::fromUtf8("m_currentDrugLabel"));
        m_currentDrugLabel->setFont(font);
        m_currentDrugLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(m_currentDrugLabel, 0, 0, 1, 1);

        m_suggestSpeedLabel = new QLabel(centralwidget);
        m_suggestSpeedLabel->setObjectName(QString::fromUtf8("m_suggestSpeedLabel"));
        m_suggestSpeedLabel->setFont(font);
        m_suggestSpeedLabel->setScaledContents(false);
        m_suggestSpeedLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(m_suggestSpeedLabel, 1, 0, 1, 1);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        m_minSuggestSpeed = new QLabel(centralwidget);
        m_minSuggestSpeed->setObjectName(QString::fromUtf8("m_minSuggestSpeed"));
        QPalette palette;
        QBrush brush(QColor(255, 0, 0, 255));
        brush.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        QBrush brush1(QColor(120, 120, 120, 255));
        brush1.setStyle(Qt::SolidPattern);
        palette.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        m_minSuggestSpeed->setPalette(palette);
        m_minSuggestSpeed->setFont(font);
        m_minSuggestSpeed->setScaledContents(false);
        m_minSuggestSpeed->setAlignment(Qt::AlignCenter);

        horizontalLayout->addWidget(m_minSuggestSpeed);

        m_toPattern = new QLabel(centralwidget);
        m_toPattern->setObjectName(QString::fromUtf8("m_toPattern"));
        m_toPattern->setFont(font);
        m_toPattern->setScaledContents(false);
        m_toPattern->setAlignment(Qt::AlignCenter);

        horizontalLayout->addWidget(m_toPattern);

        m_maxSuggestSpeed = new QLabel(centralwidget);
        m_maxSuggestSpeed->setObjectName(QString::fromUtf8("m_maxSuggestSpeed"));
        QPalette palette1;
        palette1.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette1.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette1.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        m_maxSuggestSpeed->setPalette(palette1);
        m_maxSuggestSpeed->setFont(font);
        m_maxSuggestSpeed->setScaledContents(false);
        m_maxSuggestSpeed->setAlignment(Qt::AlignCenter);

        horizontalLayout->addWidget(m_maxSuggestSpeed);


        gridLayout->addLayout(horizontalLayout, 1, 1, 1, 1);

        horizontalLayout_2 = new QHBoxLayout();
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        m_currentSpeedText = new QLabel(centralwidget);
        m_currentSpeedText->setObjectName(QString::fromUtf8("m_currentSpeedText"));
        QPalette palette2;
        palette2.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette2.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette2.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        m_currentSpeedText->setPalette(palette2);
        m_currentSpeedText->setFont(font);
        m_currentSpeedText->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(m_currentSpeedText);

        m_currentSpeed__ = new QLabel(centralwidget);
        m_currentSpeed__->setObjectName(QString::fromUtf8("m_currentSpeed__"));
        m_currentSpeed__->setFont(font);
        m_currentSpeed__->setAlignment(Qt::AlignCenter);

        horizontalLayout_2->addWidget(m_currentSpeed__);


        gridLayout->addLayout(horizontalLayout_2, 2, 1, 1, 1);


        verticalLayout_2->addLayout(gridLayout);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_2->addItem(verticalSpacer);

        verticalSpacer_4 = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        verticalLayout_2->addItem(verticalSpacer_4);

        verticalLayout = new QVBoxLayout();
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer);

        m_slider = new QSlider(centralwidget);
        m_slider->setObjectName(QString::fromUtf8("m_slider"));
        m_slider->setEnabled(false);
        QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(m_slider->sizePolicy().hasHeightForWidth());
        m_slider->setSizePolicy(sizePolicy2);
        QFont font1;
        font1.setPointSize(16);
        m_slider->setFont(font1);
        m_slider->setContextMenuPolicy(Qt::DefaultContextMenu);
        m_slider->setMinimum(0);
        m_slider->setMaximum(100);
        m_slider->setSingleStep(10);
        m_slider->setValue(50);
        m_slider->setSliderPosition(50);
        m_slider->setOrientation(Qt::Horizontal);

        horizontalLayout_4->addWidget(m_slider);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout_4->addItem(horizontalSpacer_2);


        verticalLayout->addLayout(horizontalLayout_4);

        m_sliderTimes = new QLabel(centralwidget);
        m_sliderTimes->setObjectName(QString::fromUtf8("m_sliderTimes"));
        QPalette palette3;
        palette3.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette3.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette3.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        m_sliderTimes->setPalette(palette3);
        m_sliderTimes->setFont(font);
        m_sliderTimes->setLayoutDirection(Qt::RightToLeft);
        m_sliderTimes->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(m_sliderTimes);

        verticalLayout_5 = new QVBoxLayout();
        verticalLayout_5->setObjectName(QString::fromUtf8("verticalLayout_5"));
        m_blueteethLabel = new QLabel(centralwidget);
        m_blueteethLabel->setObjectName(QString::fromUtf8("m_blueteethLabel"));
        m_blueteethLabel->setFont(font);
        m_blueteethLabel->setAlignment(Qt::AlignCenter);

        verticalLayout_5->addWidget(m_blueteethLabel);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        listWidget = new QListWidget(centralwidget);
        listWidget->setObjectName(QString::fromUtf8("listWidget"));
        QSizePolicy sizePolicy3(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(listWidget->sizePolicy().hasHeightForWidth());
        listWidget->setSizePolicy(sizePolicy3);
        listWidget->setFont(font1);
        listWidget->setVerticalScrollMode(QAbstractItemView::ScrollPerPixel);
        listWidget->setHorizontalScrollMode(QAbstractItemView::ScrollPerPixel);
        listWidget->setFlow(QListView::LeftToRight);
        listWidget->setProperty("isWrapping", QVariant(true));

        horizontalLayout_5->addWidget(listWidget);

        verticalLayout_4 = new QVBoxLayout();
        verticalLayout_4->setObjectName(QString::fromUtf8("verticalLayout_4"));
        m_openBluetoothButton = new QPushButton(centralwidget);
        m_openBluetoothButton->setObjectName(QString::fromUtf8("m_openBluetoothButton"));
        m_openBluetoothButton->setFont(font);

        verticalLayout_4->addWidget(m_openBluetoothButton);

        m_freshButton = new QPushButton(centralwidget);
        m_freshButton->setObjectName(QString::fromUtf8("m_freshButton"));
        m_freshButton->setEnabled(false);
        m_freshButton->setFont(font);

        verticalLayout_4->addWidget(m_freshButton);

        m_connectButton = new QPushButton(centralwidget);
        m_connectButton->setObjectName(QString::fromUtf8("m_connectButton"));
        m_connectButton->setEnabled(false);
        m_connectButton->setFont(font);

        verticalLayout_4->addWidget(m_connectButton);

        m_breakButton = new QPushButton(centralwidget);
        m_breakButton->setObjectName(QString::fromUtf8("m_breakButton"));
        m_breakButton->setEnabled(false);
        m_breakButton->setFont(font);

        verticalLayout_4->addWidget(m_breakButton);


        horizontalLayout_5->addLayout(verticalLayout_4);


        verticalLayout_5->addLayout(horizontalLayout_5);


        verticalLayout->addLayout(verticalLayout_5);


        verticalLayout_2->addLayout(verticalLayout);

        gridLayout_2 = new QGridLayout();
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        m_restNumLabel = new QLabel(centralwidget);
        m_restNumLabel->setObjectName(QString::fromUtf8("m_restNumLabel"));
        m_restNumLabel->setFont(font);
        m_restNumLabel->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        horizontalLayout_3->addWidget(m_restNumLabel);

        m_restNum = new QLabel(centralwidget);
        m_restNum->setObjectName(QString::fromUtf8("m_restNum"));
        QPalette palette4;
        palette4.setBrush(QPalette::Active, QPalette::WindowText, brush);
        palette4.setBrush(QPalette::Inactive, QPalette::WindowText, brush);
        palette4.setBrush(QPalette::Disabled, QPalette::WindowText, brush1);
        m_restNum->setPalette(palette4);
        m_restNum->setFont(font);
        m_restNum->setAlignment(Qt::AlignCenter);

        horizontalLayout_3->addWidget(m_restNum);


        gridLayout_2->addLayout(horizontalLayout_3, 0, 0, 1, 1);


        verticalLayout_2->addLayout(gridLayout_2);

        verticalSpacer_3 = new QSpacerItem(20, 100, QSizePolicy::Minimum, QSizePolicy::Fixed);

        verticalLayout_2->addItem(verticalSpacer_3);


        gridLayout_3->addLayout(verticalLayout_2, 0, 0, 1, 1);

        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 569, 26));
        menu = new QMenu(menubar);
        menu->setObjectName(QString::fromUtf8("menu"));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        menubar->addAction(menu->menuAction());

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        m_drugBox->setItemText(0, QCoreApplication::translate("MainWindow", "\350\215\257\345\223\2011", nullptr));
        m_drugBox->setItemText(1, QCoreApplication::translate("MainWindow", "\350\215\257\345\223\2012", nullptr));
        m_drugBox->setItemText(2, QCoreApplication::translate("MainWindow", "\350\215\257\345\223\2013", nullptr));

        m_currentSpeedLabel->setText(QCoreApplication::translate("MainWindow", "\345\275\223\345\211\215\346\273\264\351\200\237:", nullptr));
        m_currentDrugLabel->setText(QCoreApplication::translate("MainWindow", "\345\275\223\345\211\215\350\215\257\345\223\201:", nullptr));
        m_suggestSpeedLabel->setText(QCoreApplication::translate("MainWindow", "\345\273\272\350\256\256\346\273\264\351\200\237\350\214\203\345\233\264:", nullptr));
        m_minSuggestSpeed->setText(QCoreApplication::translate("MainWindow", "1.0", nullptr));
        m_toPattern->setText(QCoreApplication::translate("MainWindow", "-------", nullptr));
        m_maxSuggestSpeed->setText(QCoreApplication::translate("MainWindow", "1.5", nullptr));
        m_currentSpeedText->setText(QString());
        m_currentSpeed__->setText(QCoreApplication::translate("MainWindow", "\346\273\264\346\257\217\347\247\222", nullptr));
        m_sliderTimes->setText(QCoreApplication::translate("MainWindow", "100%", nullptr));
        m_blueteethLabel->setText(QCoreApplication::translate("MainWindow", "\350\223\235\347\211\231\346\234\252\350\277\236\346\216\245", nullptr));
        m_openBluetoothButton->setText(QCoreApplication::translate("MainWindow", "\346\211\223\345\274\200\350\223\235\347\211\231", nullptr));
        m_freshButton->setText(QCoreApplication::translate("MainWindow", "\345\210\267\346\226\260", nullptr));
        m_connectButton->setText(QCoreApplication::translate("MainWindow", "\350\277\236\346\216\245", nullptr));
        m_breakButton->setText(QCoreApplication::translate("MainWindow", "\346\226\255\345\274\200", nullptr));
        m_restNumLabel->setText(QCoreApplication::translate("MainWindow", "\347\202\271\346\273\264\345\211\251\344\275\231\351\207\217:", nullptr));
        m_restNum->setText(QCoreApplication::translate("MainWindow", "1500", nullptr));
        menu->setTitle(QCoreApplication::translate("MainWindow", "\350\223\235\347\211\231\346\216\247\345\210\266\345\231\250", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
